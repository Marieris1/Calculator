def add_num(num1,num2):
    return num1+num2
def subtract_num(num1,num2):
    return num1-num2
def multiply_num(num1,num2):
    return num1*num2
def divide_num(num1,num2):
    return num1/num2